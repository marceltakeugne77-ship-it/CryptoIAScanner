# Crypto AI Scanner V5

Scanner Android gratuit basé sur les données publiques Binance Spot. Il analyse BTC, ETH, SOL, BNB, XRP et VTHO sur 15m/1h/4h avec RSI, MACD, EMA, volume, support/résistance et un score 0–100.

## Alertes
- Notifications Android
- E-mail Gmail (destinataire préconfiguré dans l'application)
- Telegram via bot (token + Chat ID à renseigner dans l'application)
- Aucun ordre de trading automatique

## Sécurité
- Ne mets jamais un mot de passe Gmail normal dans l'application : utilise un mot de passe d'application.
- Ne mets jamais un token Telegram dans GitHub ou dans le code source.
- Les identifiants e-mail/Telegram sont enregistrés localement dans les préférences Android.

## GitHub Actions
Le workflow `.github/workflows/build-apk.yml` compile automatiquement l'APK debug à chaque push sur `main` ou manuellement avec **Run workflow**. L'APK est disponible dans les **Artifacts** de l'exécution.

## Limite importante
Le système est un moteur d'analyse quantitative à règles, pas une garantie de prédiction des prix. WorkManager peut exécuter une tâche périodique avec un délai selon les restrictions Android.
