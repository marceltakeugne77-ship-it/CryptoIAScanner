package com.cryptoaiscanner
import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters
class CryptoWorker(ctx:Context,p:WorkerParameters):Worker(ctx,p){
 override fun doWork():Result=try{Scanner.scan(applicationContext,true);Result.success()}catch(e:Exception){Result.retry()}
}
