package com.cryptoaiscanner

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.work.*
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var results: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)
        results = findViewById(R.id.results)

        val emailTo = findViewById<EditText>(R.id.emailTo)
        emailTo.setText(getSharedPreferences("email_settings", MODE_PRIVATE).getString("to", "marceltakeugne77@gmail.com"))
        findViewById<EditText>(R.id.emailFrom).setText(getSharedPreferences("email_settings", MODE_PRIVATE).getString("from", ""))
        findViewById<EditText>(R.id.telegramToken).setText(getSharedPreferences("telegram_settings", MODE_PRIVATE).getString("token", ""))
        findViewById<EditText>(R.id.telegramChatId).setText(getSharedPreferences("telegram_settings", MODE_PRIVATE).getString("chatId", ""))

        findViewById<Button>(R.id.saveEmail).setOnClickListener { saveEmailSettings() }
        findViewById<Button>(R.id.saveTelegram).setOnClickListener { saveTelegramSettings() }
        findViewById<Button>(R.id.scan).setOnClickListener { runScan() }
        findViewById<Button>(R.id.start).setOnClickListener { startAuto() }
        findViewById<Button>(R.id.stop).setOnClickListener {
            WorkManager.getInstance(this).cancelUniqueWork("crypto_ai_scan")
            status.text = "Surveillance arrêtée"
        }

        if (android.os.Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 8)
        }
    }

    private fun saveEmailSettings() {
        val from = findViewById<EditText>(R.id.emailFrom).text.toString().trim()
        val password = findViewById<EditText>(R.id.emailPassword).text.toString()
        val to = findViewById<EditText>(R.id.emailTo).text.toString().trim()
        if (from.isBlank() || password.isBlank() || to.isBlank()) {
            status.text = "Remplis les champs e-mail"
            return
        }
        getSharedPreferences("email_settings", MODE_PRIVATE).edit()
            .putString("from", from).putString("password", password).putString("to", to).apply()
        status.text = "E-mail configuré ✓"
    }

    private fun saveTelegramSettings() {
        val token = findViewById<EditText>(R.id.telegramToken).text.toString().trim()
        val chatId = findViewById<EditText>(R.id.telegramChatId).text.toString().trim()
        if (token.isBlank() || chatId.isBlank()) {
            status.text = "Ajoute le token du bot et le Chat ID"
            return
        }
        getSharedPreferences("telegram_settings", MODE_PRIVATE).edit()
            .putString("token", token).putString("chatId", chatId).apply()
        status.text = "Telegram configuré ✓"
    }

    private fun runScan() {
        status.text = "Scan multi-timeframes…"
        Thread {
            val r = Scanner.scan(this)
            runOnUiThread { status.text = "Scan terminé"; results.text = r }
        }.start()
    }

    private fun startAuto() {
        val req = PeriodicWorkRequestBuilder<CryptoWorker>(15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("crypto_ai_scan", ExistingPeriodicWorkPolicy.UPDATE, req)
        status.text = "Surveillance active : ~15 min"
    }
}
