package com.cryptoaiscanner
import android.content.Context
import androidx.core.app.NotificationCompat
import java.net.HttpURLConnection
import java.net.URL
import java.util.*
import org.json.JSONArray

data class C(val close:Double,val high:Double,val low:Double,val vol:Double)
object Scanner{
 private val symbols=listOf("BTCUSDT","ETHUSDT","SOLUSDT","BNBUSDT","XRPUSDT","VTHOUSDT")
 private fun candles(s:String,tf:String):List<C>{val u=URL("https://api.binance.com/api/v3/klines?symbol=$s&interval=$tf&limit=120")
  val x=u.openConnection() as HttpURLConnection;x.connectTimeout=8000;x.readTimeout=8000
  val a=JSONArray(x.inputStream.bufferedReader().use{it.readText()});x.disconnect()
  return (0 until a.length()).map{q->val z=a.getJSONArray(q);C(z.getString(4).toDouble(),z.getString(2).toDouble(),z.getString(3).toDouble(),z.getString(5).toDouble())}}
 private fun ema(v:List<Double>,n:Int):Double{var e=v.take(n).average();val k=2.0/(n+1);for(i in n until v.size)e=v[i]*k+e*(1-k);return e}
 private fun rsi(v:List<Double>,n:Int):Double{var g=0.0;l@for(i in 1..n){val d=v[i]-v[i-1];if(d>0)g+=d};var l=0.0;for(i in 1..n){val d=v[i]-v[i-1];if(d<0)l-=d};var ag=g/n;var al=l/n
  for(i in n+1 until v.size){val d=v[i]-v[i-1];ag=(ag*(n-1)+maxOf(d,0.0))/n;al=(al*(n-1)+maxOf(-d,0.0))/n};if(al==0.0)return 100.0;return 100-100/(1+ag/al)}
 private fun macd(v:List<Double>):Pair<Double,Double>{val a=mutableListOf<Double>();var e12=v.take(12).average();var e26=v.take(26).average()
  for(i in 26 until v.size){e12=v[i]*(2.0/13)+e12*(11.0/13);e26=v[i]*(2.0/27)+e26*(25.0/27);a.add(e12-e26)};return a.last() to ema(a,9)}
 private fun fp(x:Double)=if(x<.01)"%.8f".format(Locale.US,x) else "%.2f".format(Locale.US,x)
 fun scan(ctx:Context,notify:Boolean=true):String{val sb=StringBuilder("🧠 CRYPTO AI — SCAN MULTI-TIMEFRAME\n\n")
  for(s in symbols)try{
   val a=candles(s,"15m");val b=candles(s,"1h");val d=candles(s,"4h")
   val p=b.last().close;var score=50
   fun one(v:List<C>){val q=v.map{it.close};val e7=ema(q,7);val e25=ema(q,25);val e99=ema(q,99);val r=rsi(q,14);val (m,sg)=macd(q)
    if(p>e7)score+=4 else score-=4;if(e7>e25)score+=5 else score-=5;if(e25>e99)score+=4 else score-=4
    if(m>sg)score+=5 else score-=5;if(r in 48.0..68.0)score+=4 else if(r>73)score-=5
   }
   one(a);one(b);one(d);score=score.coerceIn(0,100)
   val sup=b.takeLast(48).minOf{it.low};val res=b.takeLast(48).maxOf{it.high};val vr=b.last().vol/b.takeLast(21).dropLast(1).map{it.vol}.average()
   if(vr>1.5)score=(score+5).coerceAtMost(100)
   val sig=when{score>=75->"🟢 ACHAT POSSIBLE";score<=30->"🔴 RISQUE ÉLEVÉ";else->"🟡 ATTENDRE"}
   val line="${s.removeSuffix("USDT")}  $sig  |  Score $score/100  |  Prix ${fp(p)}"
   sb.append(line).append("\n  RSI 1h ${"%.1f".format(Locale.US,rsi(b.map{it.close},14))} | Vol ${"%.2f".format(Locale.US,vr)}× | S ${fp(sup)} | R ${fp(res)}\n\n")
   if(notify&&(score>=80||score<=25)){ notify(ctx,line); EmailNotifier.send(ctx, "Crypto AI Scanner — ${s.removeSuffix("USDT")}", line + "\n\nAlerte générée automatiquement par Crypto AI Scanner.") }
  }catch(e:Exception){sb.append("${s.removeSuffix("USDT")} : données indisponibles\n\n")}
  return sb.toString()
 }
 private fun notify(ctx:Context,msg:String){val ch="alerts";val nm=ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
  if(android.os.Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(NotificationChannel(ch,"Alertes crypto",NotificationManager.IMPORTANCE_DEFAULT))
  nm.notify(msg.hashCode(),NotificationCompat.Builder(ctx,ch).setSmallIcon(android.R.drawable.ic_dialog_alert).setContentTitle("Crypto AI Scanner").setContentText(msg).setAutoCancel(true).build())}
}
