package com.cryptoaiscanner

import android.content.Context
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

object TelegramNotifier {
    fun send(context: Context, message: String) {
        val prefs = context.getSharedPreferences("telegram_settings", Context.MODE_PRIVATE)
        val token = prefs.getString("token", "") ?: ""
        val chatId = prefs.getString("chatId", "") ?: ""
        if (token.isBlank() || chatId.isBlank()) return
        Thread {
            try {
                val text = URLEncoder.encode(message, "UTF-8")
                val url = URL("https://api.telegram.org/bot$token/sendMessage?chat_id=${URLEncoder.encode(chatId, "UTF-8")}&text=$text")
                val conn = url.openConnection() as HttpURLConnection
                conn.connectTimeout = 10000
                conn.readTimeout = 10000
                conn.requestMethod = "GET"
                conn.inputStream.use { it.readBytes() }
                conn.disconnect()
            } catch (_: Exception) { }
        }.start()
    }
}
