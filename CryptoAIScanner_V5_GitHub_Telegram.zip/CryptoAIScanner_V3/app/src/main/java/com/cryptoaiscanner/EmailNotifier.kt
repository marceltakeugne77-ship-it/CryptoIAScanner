package com.cryptoaiscanner

import android.content.Context
import java.util.Properties
import javax.mail.Authenticator
import javax.mail.Message
import javax.mail.PasswordAuthentication
import javax.mail.Session
import javax.mail.Transport
import javax.mail.internet.InternetAddress
import javax.mail.internet.MimeMessage

object EmailNotifier {
    fun send(context: Context, subject: String, body: String) {
        val prefs = context.getSharedPreferences("email_settings", Context.MODE_PRIVATE)
        val from = prefs.getString("from", "") ?: ""
        val password = prefs.getString("password", "") ?: ""
        val to = prefs.getString("to", "") ?: ""
        if (from.isBlank() || password.isBlank() || to.isBlank()) return

        Thread {
            try {
                val props = Properties().apply {
                    put("mail.smtp.auth", "true")
                    put("mail.smtp.starttls.enable", "true")
                    put("mail.smtp.host", "smtp.gmail.com")
                    put("mail.smtp.port", "587")
                    put("mail.smtp.connectiontimeout", "10000")
                    put("mail.smtp.timeout", "10000")
                }
                val session = Session.getInstance(props, object : Authenticator() {
                    override fun getPasswordAuthentication() = PasswordAuthentication(from, password)
                })
                val message = MimeMessage(session).apply {
                    setFrom(InternetAddress(from))
                    setRecipients(Message.RecipientType.TO, InternetAddress.parse(to))
                    setSubject(subject, "UTF-8")
                    setText(body, "UTF-8")
                }
                Transport.send(message)
            } catch (_: Exception) { }
        }.start()
    }
}
